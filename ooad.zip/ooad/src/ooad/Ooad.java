/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hrirm
 */
public class Ooad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Login l = null;
        try {
            l = new Login();
        } catch (SQLException ex) {
            Logger.getLogger(Ooad.class.getName()).log(Level.SEVERE, null, ex);
        }
        l.setVisible(true);
    }
    
}
